****************************
* Simple bank app via Java *
****************************

i. Domain design
ii. Assumptions
iii. Test cases and edge considerations
iv. How to run code/tests
v. Improvements

***
***
***

I. The bank domain was designed by identifying the class, attributes and methods.

Classes
=======
Bank
Account

Bank Class Attributes
=====================
bankBalance
ArrayList of Account

Account Class Attributes
========================
customerAccountNo
customerBalance
customerName

Bank Class Method
=================
addAccount()
getBankBalance() 


Account Class Methods
=====================
deposit()
withdraw()
getCustomerBalance() 

The class, attributes and methods were translated into code by the use of the Java IDE named Eclipse. 

Constructors were created. Getters were also created. There were two important getters: the get customer balance and the get bank balance. In the get customer balance, it returns the customer balance after all the transactions (deposits and/or withdrawals) were done to the account. In the get bank balance, the array list of accounts were processed and the customer balances were all added, and it returns the bank balance. 

The setter method were not included since the Bank and Customer information are only set once. The toString method was also created. 

There were two important methods used for processing the accounts: the deposit method and withdraw method. In the deposit method, the customer can deposit any amount, and it will be added to the customer balance. Codes were added to ensure that customers will not be allowed a negative amount of deposit.  In the withdraw method, the customer can withdraw any amount not exceeding their current customer balance, and it will be deducted to the customer balance. Codes were also added to ensure that customers will not be allowed a negative amount of withdrawal.

***
***
***

II. The Bank and Account classes were created with the following assumptions:
1. The customer account have only 3 attributes, account number, balance and name. Account number have a data type of string. Name does not consider the middle name and/or last name.
2. The bank have only 2 attributes which is the bank balance and the array list of customer accounts.
3. The empty constructor was created with the following default values:
customerAccountNo = "C9999"
customerBalance = 0.0
customerName = "JohnDoe"
4. An 'IllegalArgumentException' was thrown as well as a display message for negative and insufficient fund transactions.
5. There were no amount limit set when depositing or withdrawing.

***
***
***

III. Test cases and edge considerations
There were 11 test cases created. Test cases for the constructors, setters and getters were not created. Test cases were concentrated with the two methods: deposit() and withdraw(). Additionally, in testing the getter for customer balance,  getter for bank balance, and transactions by single and multiple customers.
Test Cases 1, 3, 6, and 7: Valid deposit and valid withdraw transactions
Test Cases 2 and 4: Invalid deposit and invalid withdraw transactions because of negative amount
Test Cases 5: Invalid withdraw transaction because of insufficient fund
Test Cases 8: Valid customer balance using deposit and withdraw transactions by one customer
Test Cases 10: Valid customer balances using deposit and withdraw transactions by multiple customers
Test Cases 9: Valid bank balance using deposit and withdraw transactions by one customer
Test Cases 11: Valid bank balance using deposit and withdraw transactions by multiple customers

***
***
***

IV. There are two options on how to run the code and tests

OPTION 1: Running via command line, starting in the Project directory ("Banking") of the uncompressed file:
========
The code has been written to work on the Java release supported by gradle which is `Java 16`. Gradle is used for building and running. To build, run the command "./gradlew build". To execute the junit test cases, run the command "./gradlew test". To execute the driver test cases for the Account class with lots of displays, run the command "java -jar build\libs\Banking-1.0-SNAPSHOT.jar".

OPTION 2: Running via Eclipse IDE:
========
Pre-requisite: You need to have a Java project file 
1. Launch Eclipse IDE and select ‘Import’ from ‘File’ menu.
2. In the displayed ‘Import’ dialog, expand the ‘General’ folder. Select ‘Archive’. In the 'From Archive file:', hit browse and navigate to the location of the zipped file named 'src.zip'. In the 'Into folder:', hit browse and navigate to the location of the Java project directory And finally click ‘Finish’.
3. Select ‘Show View’ from ‘Window’ menu and hit 'Project Explorer'. In the 'Project Explorer', select your Java project, expand it to see 'src' folder, expand it furthermore and you will see the 'banking' package and under it are the 4 files: Bank.java, Account.java, BankAccountTest.java, BankAccountDriver.java.
4. 'Bank.java' is the source code for the Bank class. Furthermore, 'Account.java' is the source code for the Account class. Double click it to see the source code in another window. Ensure that ‘Build Automatically’ is ticked from ‘Project’ menu to compile the source code.
5. 'BankAccountTest.java' are the test unit cases for the Bank and Account classes. Double click it to see the source code in another window. Select ‘Run’ from ‘Run’ menu to execute the test unit cases. Alternatively, you can hit the Run button, green circle with the right triangle icon. Or, you can use shortcut key CTRL + F11. Console Window will open up where the displays in the code will be seen. The Junit window will also open up and it will show the number of runs, errors and failures. The expected run is 11/11, 0 errors and 0 failures.     
6. 'BankAccountDriver.java' is a test driver for the Account class which contains the main program. Double click it to see the source code in another window.  
***
***
***

V. Improvements
1. Customer attributes can be enhanced and improved by adding customer information such as email, address, full name, mobile number and other important information about the customer,
2. Bank attributes can be enhanced and improved by adding bank information like bank name, branch name, branch number, telephone number and other important bank information.
3. The 'IllegalArgumentException' for the negative deposit and withdraw transactions can be replaced with a more appropriate exception.
4. The 'IllegalArgumentException' for the insufficient fund transaction can be replaced with the 'InsufficientFundsException'
5. The test cases can be created in a parameterized way.
6. 'BankAccountDriver.java' is a test driver, which can also include Bank class test cases with lots of displays.  

