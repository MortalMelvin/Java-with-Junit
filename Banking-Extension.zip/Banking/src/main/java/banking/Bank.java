package banking;

import java.util.ArrayList;

public class Bank {

    // attribute for Bank balance
    private double bankBalance = 0.0;

    // attribute for List of Accounts
    private ArrayList<Account> accounts;

    // constructor for Bank
    public Bank(double bankBalance) {
        this.bankBalance = bankBalance;
        this.accounts = new ArrayList<Account>();
    }


    // Calculate the Bank Balance from the List of Accounts
    public double getBankBalance() {
        System.out.println("\nAccount List:");
        System.out.println("Customer Account Number ==>  Customer Balance ==>  Customer Name");

        for(int i=0; i<this.accounts.size(); i++) {
            System.out.println((i+1) + ". " +
                    this.accounts.get(i).getAccountNo() + " ==> " +
                    "$" + String.format("%.2f", this.accounts.get(i).getCustomerBalance()) + " ==> " +
                    this.accounts.get(i).getCustomerName());
        }

        bankBalance = 0.0;

        for(int i=0; i<this.accounts.size(); i++) {
            bankBalance += this.accounts.get(i).getCustomerBalance();
        }

        System.out.println("Total bank balance is $" + String.format("%.2f", this.bankBalance));

        return bankBalance;
    }

    // Add an Account to the List of Accounts
    public void addAccount(Account anAccount) {
        this.accounts.add(anAccount);
    }

    // deposit method
    public void deposit (Account account, double amount) {
        bankBalance = getBankBalance();
        bankBalance += amount;
        account.deposit(amount);
        return;
    }

    // withdraw method
    public void withdraw (Account account, double amount) {
        bankBalance = getBankBalance();
    //    if (bankBalance
        if (amount > account.getCustomerBalance()){
            if (amount > bankBalance) {
                throw new IllegalArgumentException();
            }
            else {
                account.withdraw(amount);
                bankBalance -= amount;
            }
        }
        else {
            account.withdraw(amount);
            bankBalance -= amount;
        }

        //account.withdraw(amount);
        return;
    }


}
