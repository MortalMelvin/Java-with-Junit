package banking;

public class Account {
    // attributes belonging to Customer Account
    private final String customerAccountNo;
    private double customerBalance;
    private final String customerName;

    // deposit method
    public double deposit (double amount) {
        // Customers are not allowed to deposit negative amount
        if (amount <= 0) {
            System.out.println("\nDeposit of $" + String.format("%.2f", amount) + " is unsuccessful. Only positive amount of deposit will be accepted and processed.");
            throw new IllegalArgumentException();
        }
        else {
            // Customers are allowed to deposit any amount
            System.out.println("\nCustomer " + this.customerName + " with account number " + this.customerAccountNo  + " have a current balance of $" + String.format("%.2f", this.customerBalance));
            this.customerBalance += amount;
            System.out.println("Deposit of $" + String.format("%.2f", amount) + " successfully processed.\nNew balance is $" + String.format("%.2f", this.customerBalance));
        }
        return customerBalance;
    }

    // withdraw method
    public double withdraw (double amount) {
        // Customers are not allowed to withdraw negative amount
        if (amount <= 0) {
            System.out.println("\nWithdrawal of $" + String.format("%.2f", amount) + " is unsuccessful. Only positive amount of withdrawal will be accepted and processed.");
            throw new IllegalArgumentException();
        }
        // Customers are only allowed to withdraw amount not in excess of their current balance
        //else if (amount > this.customerBalance) {
        //    System.out.println("\nOnly $" + String.format("%.2f", this.customerBalance) + " available. Withdrawal of $"+ String.format("%.2f", amount) + " not processed");
        //    throw new IllegalArgumentException();

        //}
        else {
            System.out.println("\nCustomer " + this.customerName + " with account number " + this.customerAccountNo  + " have a current balance of $" + String.format("%.2f", this.customerBalance));
            this.customerBalance -= amount;
            System.out.println("Withdrawal of $" + String.format("%.2f", amount) + " successfully processed.\nRemaining balance is $" + String.format("%.2f", this.customerBalance));
        }
        return customerBalance;
    }

    // empty constructor
    public Account() {
        //default values
        this("C9999", 0.0, "JohnDoe");
    }

    // constructor with parameters
    public Account(String accountNo, double customerBalance, String customerName) {
        this.customerAccountNo = accountNo;
        this.customerBalance = customerBalance;
        this.customerName = customerName;
    }

    // getter methods
    public String getAccountNo() {
        return customerAccountNo;
    }

    public double getCustomerBalance() {
        return customerBalance;
    }

    public String getCustomerName() {
        return customerName;
    }

    // toString method
    public String toString() {
        return ("\nCustomer " + this.customerName + " with account number " + this.customerAccountNo  + " has balance of $" + String.format("%.2f", this.customerBalance) + ".");
    }
}
