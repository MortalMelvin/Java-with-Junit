package banking;

public class BankAccountDriver {

    public static void main(String[] args) {
        new BankAccountDriver();
    }

    public BankAccountDriver() {
        Account ba1 = new Account();
        Account ba2 = new Account("C0001", 30, "Alice");
        Account ba3 = new Account("C0002", 50, "Bobby");
        Account ba4 = new Account("C0003", 70, "Charlie");

        System.out.println (ba1.toString());
        System.out.println (ba2.toString());
        System.out.println (ba3.toString());
        System.out.println (ba4.toString());

        System.out.println (ba1.toString());
        ba1.deposit(30);
        System.out.println (ba1.toString());

        System.out.println (ba1.toString());
        ba1.withdraw(15);
        System.out.println (ba1.toString());

//		System.out.println (ba1.toString());
//		ba1.deposit(-100);
//		System.out.println (ba1.toString());

//		System.out.println (ba2.toString());
//		ba2.withdraw(100);
//		System.out.println (ba2.toString());

//		System.out.println (ba1.toString());
//		ba1.withdraw(15.01);
//		System.out.println (ba1.toString());

        System.out.println (ba1.toString());
        ba1.withdraw(14.99);
        System.out.println (ba1.toString());

//		System.out.println (ba2.toString());
//		ba2.withdraw(50);
//		System.out.println (ba2.toString());

        System.out.println (ba2.toString());
        ba2.withdraw(30);
        System.out.println (ba2.toString());

//		System.out.println (ba1.toString());
//		ba1.withdraw(-0.02);
//		System.out.println (ba1.toString());

        System.out.println (ba1.toString());
        ba1.deposit(10);
        System.out.println (ba1.toString());

        System.out.println (ba2.toString());
        ba2.deposit(20);
        System.out.println (ba2.toString());

        System.out.println (ba3.toString());
        ba3.deposit(35);
        System.out.println (ba3.toString());

        System.out.println (ba4.toString());
        ba4.withdraw(15);
        System.out.println (ba4.toString());
    }
}
