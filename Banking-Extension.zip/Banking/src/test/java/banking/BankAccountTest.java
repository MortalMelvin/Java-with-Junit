package banking;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankAccountTest {

    // Test Case 01: Valid deposit transaction
    @Test
    void testDeposit() {
        Account ba1 = new Account("C0001", 0, "Alice");
        double balance = ba1.deposit(30);
        assertEquals(30, balance, 0);
    }

    // Test Case 02: Invalid deposit transaction because of negative amount
    @Test
    void testDeposit_NegativeAmount() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> {
            Account ba1 = new Account("C0001", 30, "Alice");
            ba1.deposit(-40);
        });
    }

    // Test Case 03: Valid withdraw transaction
    @Test
    void testWithdraw() {
        Account ba1 = new Account("C0001", 30, "Alice");
        double balance = ba1.withdraw(20);
        assertEquals(10, balance, 0);
    }

    // Test Case 04: Invalid withdraw transaction because of negative amount
    @Test
    void testWithdraw_NegativeAmount() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> {
            Account ba1 = new Account("C0001", 10, "Alice");
            ba1.withdraw(-10);
        });
    }

    // Test Case 05: Invalid withdraw transaction because of insufficient fund
    @Test
    void testWithdraw_InsufficientFunds() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> {
            Account ba1 = new Account("C0001", 10, "Alice");
            ba1.withdraw(11);
        });
    }

    // Test Case 06: Valid deposit transaction
    @Test
    void testGetCustomerBalance_AfterDeposit() {
        Account ba1 = new Account("C0001", 10, "Alice");
        ba1.deposit(30);
        assertEquals(40, ba1.getCustomerBalance(), 0);
    }

    // Test Case 07: Valid withdraw transaction
    @Test
    void testGetCustomerBalance_AfterWithdraw() {
        Account ba1 = new Account("C0001", 40, "Alice");
        ba1.withdraw(20);
        assertEquals(20, ba1.getCustomerBalance(), 0);
    }

    // Test Case 08: Valid customer balance using deposit and withdraw transactions by one customer
    @Test
    void testGetCustomerBalance_AfterDepositAndWithdraw() {
        Account ba1 = new Account("C0001", 0, "Alice");
        ba1.deposit(30);
        ba1.withdraw(20);
        assertEquals(10, ba1.getCustomerBalance(), 0);
    }

    // Test Case 09: Valid bank balance using deposit and withdraw transactions by one customer
    @Test
    void testGetBankBalance_AfterDepositAndWithdraw_OneCustomer() {
        Bank theBank = new Bank(0.0);
        Account ba1 = new Account("C0001", 0, "Alice");
        theBank.addAccount(ba1);
        theBank.deposit(ba1, 30);
        theBank.withdraw(ba1, 20);

//        assertEquals(30, theBank.getBankBalance(), 0);
        assertEquals(10, theBank.getBankBalance(), 0);

    }

    // Test Case 10: Valid customer balances using deposit and withdraw transactions by multiple customers
    @Test
    void testGetCustomerBalance_AfterDepositAndWithdraw_MultipleCustomers() {
        Account ba1 = new Account("C0001", 10, "Alice");
        Account ba2 = new Account("C0002", 200, "Bobby");
        Account ba3 = new Account("C0003", 300, "Charlie");
        ba1.deposit(30);
        ba1.withdraw(15);
        ba2.deposit(50);
        ba2.withdraw(30);
        ba3.deposit(70);
        ba3.withdraw(45);
        assertEquals(25, ba1.getCustomerBalance(), 0);
        assertEquals(220, ba2.getCustomerBalance(), 0);
        assertEquals(325, ba3.getCustomerBalance(), 0);
    }

    // Test Case 11: Valid bank balance using deposit and withdraw transactions by multiple customers
    @Test
    void testGetBankBalance_AfterDepositAndWithdraw_MultipleCustomers() {
        Bank theBank = new Bank(0.0);
        Account ba1 = new Account("C0001", 10, "Alice");
        Account ba2 = new Account("C0002", 200, "Bobby");
        Account ba3 = new Account("C0003", 300, "Charlie");
        theBank.addAccount(ba1);
        theBank.addAccount(ba2);
        theBank.addAccount(ba3);
        ba1.deposit(30);
        ba1.withdraw(15);
        ba2.deposit(50);
        ba2.withdraw(30);
        ba3.deposit(70);
        ba3.withdraw(45);
        assertEquals(570, theBank.getBankBalance(), 0);
    }

    // Test Case 09: Valid bank balance using deposit and withdraw transactions by one customer
    @Test
    void testoverrun() {
        Bank theBank = new Bank(0.0);
        Account ba1 = new Account("C0001", 0, "Alice");
        Account ba2 = new Account("C0002", 0, "Bob");
        theBank.addAccount(ba1);
        theBank.addAccount(ba2);
        theBank.deposit(ba1, 30);
        theBank.deposit(ba2, 50);
        theBank.withdraw(ba1, 50);
//        assertEquals(30, theBank.getBankBalance(), 0);
        assertEquals(30, theBank.getBankBalance(), 0);

    }

}