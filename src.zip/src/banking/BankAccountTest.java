package banking;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BankAccountTest {

	// Test Case 01: Valid deposit transaction
	@Test
	void testDeposit() {
		BankAccount ba1 = new BankAccount("C0001", 0, "Alice", 0);
		double balance = ba1.deposit(30);
        assertEquals(30, balance, 0);
	}
	
	// Test Case 02: Invalid deposit transaction because of negative amount
	@Test
	void testDeposit_NegativeAmount() throws Exception {
		assertThrows(IllegalArgumentException.class, () -> {
			BankAccount ba1 = new BankAccount("C0001", 30, "Alice", 0);
			ba1.deposit(-40);
		});
	}

	// Test Case 03: Valid withdraw transaction
	@Test
	void testWithdraw() {
		BankAccount ba1 = new BankAccount("C0001", 30, "Alice", 0);
		double balance = ba1.withdraw(20);
        assertEquals(10, balance, 0);	
    }

	// Test Case 04: Invalid withdraw transaction because of negative amount
	@Test
	void testWithdraw_NegativeAmount() throws Exception {
		assertThrows(IllegalArgumentException.class, () -> {
			BankAccount ba1 = new BankAccount("C0001", 10, "Alice", 0);
			ba1.withdraw(-10);
		});
	}
	
	// Test Case 05: Invalid withdraw transaction because of insufficient fund
	@Test
	void testWithdraw_InsufficientFunds() throws Exception {
		assertThrows(IllegalArgumentException.class, () -> {
			BankAccount ba1 = new BankAccount("C0001", 10, "Alice", 0);
			ba1.withdraw(11);

		});
	}
	
	// Test Case 06: Valid deposit transaction
	@Test
	void testGetCustomerBalance_AfterDeposit() {
		BankAccount ba1 = new BankAccount("C0001", 10, "Alice", 0);
		ba1.deposit(30);
        assertEquals(40, ba1.getCustomerBalance(), 0);
	}

	// Test Case 07: Valid withdraw transaction
	@Test
	void testGetCustomerBalance_AfterWithdraw() {
		BankAccount ba1 = new BankAccount("C0001", 40, "Alice", 0);
		ba1.withdraw(20);
        assertEquals(20, ba1.getCustomerBalance(), 0);
	}
	
	// Test Case 08: Valid customer balance using sequential deposit and withdraw transactions by 1 customer
	@Test
	void testGetCustomerBalance_AfterDepositAndWithdraw() {
		BankAccount ba1 = new BankAccount("C0001", 0, "Alice", 0);
		ba1.deposit(30);
		ba1.withdraw(20);
        assertEquals(10, ba1.getCustomerBalance(), 0);
	}	
	
	// Test Case 09: Valid bank balance using sequential transactions by 1 customer
	@Test
	void testGetBankBalance_AfterAlicesTransactions() {
		BankAccount ba1 = new BankAccount("C0001", 10, "Alice", 10);
		assertEquals(10, ba1.getBankBalance(), 0);
	}
	
	// Test Case 10: Valid customer balances using deposit and withdraw transactions by multiple customers
	@Test
	void testGetCustomerBalance_AfterDepositAndWithdraw_MultipleCustomers() {
		BankAccount ba1 = new BankAccount("C0001", 10, "Alice", 0);
		BankAccount ba2 = new BankAccount("C0002", 200, "Bobby", 0);
		BankAccount ba3 = new BankAccount("C0003", 300, "Charlie", 0);
		ba1.deposit(30);
		ba1.withdraw(15);
		ba2.deposit(50);
		ba2.withdraw(30);
		ba3.deposit(70);
		ba3.withdraw(45);
		assertEquals(25, ba1.getCustomerBalance(), 0);
		assertEquals(220, ba2.getCustomerBalance(), 0);
		assertEquals(325, ba3.getCustomerBalance(), 0);
	}	

}
