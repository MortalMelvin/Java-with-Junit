package banking;

public class BankAccount {
	// attribute belonging to the object/instance
	private String customerAccountNo;
	private double customerBalance;
	private String customerName;
	
	// attribute belonging to the class
	private static double bankBalance = 0.0;

	// deposit method
	public double deposit (double amount) {
		// Customers are not allowed to deposit negative amount
		if (amount <= 0) {
	        System.out.println("Deposit of $" + String.format("%.2f", amount) + " is unsuccessful. Only positive amount of deposit will be accepted and processed.");
            throw new IllegalArgumentException();
		}
		else {
			// Customers are allowed to deposit any amount
	        System.out.println("\nCustomer " + this.customerName + "'s current balance is $" + String.format("%.2f", this.customerBalance));
			this.customerBalance += amount;
			this.bankBalance += amount;
	        System.out.println("Deposit of $" + String.format("%.2f", amount) + " successfully processed.\nNew balance is $" + String.format("%.2f", this.customerBalance));
	        System.out.println("Total bank balance is $" + String.format("%.2f", this.bankBalance));
		}
        return customerBalance;
	}

	// withdraw method
	public double withdraw (double amount) {
		// Customers are not allowed to withdraw negative amount
		if (amount <= 0) {
	        System.out.println("Withdrawal of $" + String.format("%.2f", amount) + " is unsuccessful. Only positive amount of withdrawal will be accepted and processed.");
            throw new IllegalArgumentException();
		}
		// Customers are only allowed to withdraw amount not in excess of their current balance
		else if (amount > this.customerBalance) {
            System.out.println("Only $" + String.format("%.2f", this.customerBalance) + " available. Withdrawal of $"+ String.format("%.2f", amount) + " not processed");
            throw new IllegalArgumentException();
			}
		else {
	        System.out.println("\nCustomer " + this.customerName + "'s current balance is $" + String.format("%.2f", this.customerBalance));
			this.customerBalance -= amount;
			this.bankBalance -= amount;
	        System.out.println("Withdrawal of $" + String.format("%.2f", amount) + " successfully processed.\nRemaining balance is $" + String.format("%.2f", this.customerBalance));
	        System.out.println("Total bank balance is $" + String.format("%.2f", this.bankBalance));
		}
        return customerBalance;
	}

	// empty constructor
	public BankAccount() {
		//default values
		this("C9999", 0.0, "JohnDoe", 0.0);
	}
	
	// constructor with parameters
	public BankAccount(String accountNo, double customerBalance, String customerName, double bankBalance) {
		this.customerAccountNo = accountNo;
		this.customerBalance = customerBalance;
		this.customerName = customerName;
		this.bankBalance += customerBalance;
	}

	// getters and setters methods
	public String getAccountNo() {
		return customerAccountNo;
	}

	public void setAccountNo(String accountNo) {
		this.customerAccountNo = accountNo;
	}

	public double getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(double balance) {
		this.customerBalance = balance;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public double getBankBalance() {
		return bankBalance;
	}

	public void setBankBalance(double bankBalance) {
		this.bankBalance = bankBalance;
	}

	// toString method
	public String toString() {
		return ("\nCustomer " + this.customerName + " with account number " + this.customerAccountNo  + " has balance of $" + String.format("%.2f", this.customerBalance) + ".\nTotal bank balance is $" + String.format("%.2f", this.bankBalance));
	}
}
